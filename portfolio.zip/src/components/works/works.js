import React from 'react'
import './works.css';
import portfolio1 from "../../assets/portfolio-1.png";
import portfolio2 from "../../assets/portfolio-2.png";
import portfolio3 from "../../assets/portfolio-3.png";



const Works = () => {
  return (
    <section id='works'>
        <h2 className='worktitle'>My Portfolio</h2>
        <span className='workdes'>I'm currently pursuing my undergraduate studies at KCT, where I'm actively exploring new horizons and nurturing my passion for learning. I'm a self-driven individual with a strong desire to expand my knowledge. My commitment to personal and professional growth drives me to seek out opportunities for skill development and stay updated on industry trends and best practices.</span>      
        <div className='workimgs'>
            <img src={portfolio1} alt='' className='workimg'></img>
            <img src={portfolio2} alt='' className='workimg'></img>
            <img src={portfolio3} alt='' className='workimg'></img>
        </div>
        <button className='workbtn'>See more</button>
    </section>
  );
}

export default Works
